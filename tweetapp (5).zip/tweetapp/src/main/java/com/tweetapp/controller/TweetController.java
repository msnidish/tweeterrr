package com.tweetapp.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tweetapp.exception.TweetAppExceptionHandler;
import com.tweetapp.model.Like;
import com.tweetapp.model.Tweet;
import com.tweetapp.model.TweetReply;
import com.tweetapp.repository.TweetRepo;
import com.tweetapp.service.TweetServiceImpl;

//@CrossOrigin(origins= "http://localhost:4200")
@RestController
@RequestMapping("/api/v1.0/tweets")
public class TweetController {

	@Autowired
	TweetServiceImpl tweetServiceImpl;
	
	@Autowired
	AuthController authController;
	
//	public Producer producer;
//	
//	@Autowired
//	public TweetController(Producer producer) {
//		super();
//		this.producer = producer;
//	}
//	
	@Autowired
	TweetRepo tweetRepo;
	
//	@GetMapping("/publish")
//	public String sendMessage(@PathVariable String message) {
//		this.producer.sendMessage(message);
//		return "Connection established";
//	}
	@GetMapping("/all")
	public Map<String, List<String>> getAllTweets(@RequestHeader(name = "Authorization") String token) throws TweetAppExceptionHandler {
		if(authController.validate(token)) 
			return tweetServiceImpl.viewTweetByAllUser();
		else
			throw new TweetAppExceptionHandler("Invalid Token");
	}
	
	@GetMapping("/{username}")
	public List<Tweet> getTweetByUser(@RequestHeader(name = "Authorization") String token,@PathVariable String username) throws TweetAppExceptionHandler {
		if(authController.validate(token))
			return tweetServiceImpl.viewTweetByUser(username);
		else
			throw new TweetAppExceptionHandler("Invalid Token");
	}
	
	@PostMapping("/{username}/add")
	public Tweet addPost(@RequestHeader(name = "Authorization") String token,@PathVariable String username,@RequestBody Tweet tweet) throws TweetAppExceptionHandler {
		if(authController.validate(token)) {
			if(username.equalsIgnoreCase(tweet.getEmail())) {
				return tweetServiceImpl.postATweet(tweet);
			}
			return tweet;
		}else
			throw new TweetAppExceptionHandler("Invalid token");
		
	}
	
	@PutMapping("/{username}/update/{id}")
	public void updateTweet(@RequestHeader(name = "Authorization") String token,@PathVariable String username,@PathVariable int id,@RequestBody Tweet tweet) throws TweetAppExceptionHandler {
		if(authController.validate(token)) {
		if(username.equalsIgnoreCase(tweet.getEmail())) {
			System.out.println("Inside update tweet if");
			 tweetServiceImpl.updateTweet(tweet.getEmail(), tweet.getTweet(), id);
		}
		}else
			throw new TweetAppExceptionHandler("Invalid token");
	}
	
	@DeleteMapping("/{username}/delete/{id}")
	public List<Tweet> deleteTweet(@RequestHeader(name = "Authorization") String token,@PathVariable String username,@PathVariable int id) throws TweetAppExceptionHandler {
		if(authController.validate(token)) 
			return tweetServiceImpl.deleteTweet(username, id);
		else
			throw new TweetAppExceptionHandler("Invalid Token");
	}
	
	@PostMapping("/addLike")
	public Like addLike(@RequestHeader(name = "Authorization") String token,@RequestBody Like like) throws TweetAppExceptionHandler {
		if(authController.validate(token)) 
			return tweetServiceImpl.likeTweet(like);
		else
			throw new TweetAppExceptionHandler("Invalid Token");
	}
	
	@GetMapping("/getLikes")
	public List<Like> getAllLikes(@RequestHeader(name = "Authorization") String token) throws TweetAppExceptionHandler{
		if(authController.validate(token)) 
			return tweetServiceImpl.getAllLikes();
		else
			throw new TweetAppExceptionHandler("Invalid Token");
	}
	
	@PostMapping("/reply")
	public TweetReply postTweetReply(@RequestHeader(name = "Authorization") String token,@RequestBody TweetReply tweetReply) throws TweetAppExceptionHandler {
		if(authController.validate(token)) 
			return tweetServiceImpl.postReply(tweetReply);
		else
			throw new TweetAppExceptionHandler("Invalid Token");
	}
	
	@GetMapping("/getreply")
	public Map<String, List<String>> getAllReplies(@RequestHeader(name = "Authorization") String token) throws TweetAppExceptionHandler{
		if(authController.validate(token)) 
			return tweetServiceImpl.getAllReply();
		else
			throw new TweetAppExceptionHandler("Invalid Token");
	}
}
