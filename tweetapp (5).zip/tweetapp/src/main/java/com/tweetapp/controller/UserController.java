package com.tweetapp.controller;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.tweetapp.exception.TweetAppExceptionHandler;
import com.tweetapp.model.Login;
import com.tweetapp.model.User;
import com.tweetapp.repository.LoginRepo;
import com.tweetapp.repository.UsersRepo;
import com.tweetapp.service.UserServiceImpl;

//@CrossOrigin(origins="http://localhost:4200")
@RestController
public class UserController {

	@Autowired
	UserServiceImpl userServiceImpl;
	@Autowired
	UsersRepo userRepo;
	@Autowired
	LoginRepo loginRepo;
	@Autowired
	AuthController authController;
	
	@PostMapping("/api/v1.0/tweets/register")
	public String registerUser( @RequestBody User user) throws SQLException {
		System.out.println("controller start");
		loginRepo.addDetails(user.getEmail(),user.getPassword());
		userServiceImpl.register(user);
		return "User registration is successful!!";
	}
	
	@PostMapping("/api/v1.0/tweets/{username}/forgot")
	public String forgotPassword(@RequestHeader(name = "Authorization") String token, @PathVariable String username,@RequestBody Login login) {
		if(authController.validate(token)) {
		User u=userRepo.findByEmail(username);
		if(u!=null) {
			loginRepo.updatePassword(username, login.getPassword());
			userServiceImpl.forgotPassword(username, login.getPassword());
			return "User Updated successfully";
		}
		return "User Not Found";
	 }else {
		 return "Invalid Token";
	 }
	}
	
	@GetMapping("/api/v1.0/tweets/users/all")
	public List<User> getAllUsers(@RequestHeader(name = "Authorization") String token) throws TweetAppExceptionHandler {
		if(authController.validate(token)) {
		return userServiceImpl.viewAllUsers();
		}
		else {
			throw new TweetAppExceptionHandler("Invalid Token");
		}
	}
	
	@GetMapping("/api/v/1.0/tweets/user/search/{username}")
	public User getUser(@RequestHeader(name = "Authorization") String token,@PathVariable String username) throws TweetAppExceptionHandler {
		if(authController.validate(token)) {
		return userServiceImpl.findUser(username);
		}else
			throw new TweetAppExceptionHandler("Invalid Token");
	}
}
