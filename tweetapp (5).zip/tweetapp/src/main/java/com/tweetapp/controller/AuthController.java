package com.tweetapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.tweetapp.model.Login;
import com.tweetapp.security.jwt.JwtUtil;
import com.tweetapp.service.LoginServiceImpl;

import lombok.extern.slf4j.Slf4j;

/**
 * Class for Authorization Controller
 * 
 * @author Spandana, Sravani, Sundar, Jayakeerthi, Swaroop
 * 
 */
@RestController
@Slf4j
public class AuthController {

	@Autowired
	private JwtUtil jwtUtil;

	@Autowired
	private LoginServiceImpl loginServiceImpl;

	/**
	 * Method to validate the token
	 * 
	 * @param token1 This is the token send for authentication
	 * @return This returns true/false based on token validity
	 */
	@GetMapping("/validate")
	public boolean validate(@RequestHeader(name = "Authorization") String token1) {
		String token = token1.substring(7);
		try {
			Login user = loginServiceImpl.loadLoginByEmail(jwtUtil.extractUsername(token));		
			if (jwtUtil.validateToken(token, user)) {
				log.info("Token Validate successful");
				return true;
			}else {
				log.info("Token validate unsuccessful");
			return false;
			}
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * Method to check whether login credentials are correct or not
	 * 
	 * @param userCredentials user credentials contain user name and password
	 * @return This returns token on successful login else throws exception
	 */
	@PostMapping("/api/v1.0/tweets/login")
	public String login(@RequestBody Login userCredentials) {
		System.out.println("login method");
		System.out.println(userCredentials.getEmail()+" "+userCredentials.getPassword());
		if (userCredentials.getEmail() == null || userCredentials.getPassword() == null
				|| userCredentials.getEmail().trim().isEmpty() || userCredentials.getPassword().trim().isEmpty()) {
			log.debug("Login unsuccessful --> User name or password is empty");
			return "User name or password cannot be Null or Empty";
		}

		else if (jwtUtil.isNumeric(userCredentials.getEmail())) {
			log.debug("Login unsuccessful --> User name is numeric");
			return "User name is numeric";
		}

		else {
			try {
				System.out.println("Try");
				Login user = loginServiceImpl.loadLoginByEmail(userCredentials.getEmail());
				System.out.println(user);
				if (user.getPassword().equals(userCredentials.getPassword())) {
					String token = jwtUtil.generateToken(user.getEmail());
					log.debug("Login successful");
					return token;
				} else {
					log.debug("Login unsuccessful --> Invalid password");
					return "Password is wrong";
				}
			} catch (Exception e) {
				log.debug("Login unsuccessful --> Invalid Credential");
				return "Invalid Credential";
			}
		}
	}
}
