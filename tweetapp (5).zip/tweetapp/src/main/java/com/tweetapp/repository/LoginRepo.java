package com.tweetapp.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.tweetapp.model.Login;

@Repository
public interface LoginRepo extends JpaRepository<Login, String>{

	//@Query(value="select * from login where email=?0 ", nativeQuery=true)
	public Login findByEmail(String email);
	
	@Modifying
	@Query(value="insert into login(email,password) values(:email,:password)",nativeQuery = true)
	@Transactional
	public void addDetails(@Param("email") String email,@Param("password") String password);
	
	@Modifying
	@Query("update Login l set l.password=:password where l.email=:email")
	@Transactional
	void updatePassword(@Param("email") String email,@Param("password") String newPassword);
}
