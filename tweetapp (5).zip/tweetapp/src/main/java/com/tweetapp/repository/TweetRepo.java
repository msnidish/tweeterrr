package com.tweetapp.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.tweetapp.model.Tweet;

@Repository
public interface TweetRepo extends JpaRepository<Tweet,String>{

	Tweet findByTid (int tid);

	List<Tweet> findByEmail(String email);

	void deleteByTid(int Tid);

	@Transactional
	void deleteByEmailAndTid(String email, int id);

	@Modifying
	@Query("update Tweet t set t.tweet=:tweet where t.email=:email and t.tid=:tid")
	@Transactional
	void updateTweet(@Param("email") String email,@Param("tweet") String tweet,@Param("tid") int tid);
}
