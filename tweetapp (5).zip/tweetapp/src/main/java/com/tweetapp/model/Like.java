package com.tweetapp.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tweetlike")
public class Like {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	@Column
	private String tweetId;
	private String likedBy;
	public String getTweetId() {
		return tweetId;
	}
	public void setTweetId(String tweetId) {
		this.tweetId = tweetId;
	}
	public String getLikedBy() {
		return likedBy;
	}
	public void setLikedBy(String likedBy) {
		this.likedBy = likedBy;
	}
	public Like(String tweetId, String likedBy) {
		super();
		this.tweetId = tweetId;
		this.likedBy = likedBy;
	}
	public Like() {
		super();
	}
	@Override
	public String toString() {
		return "Like [tweetId=" + tweetId + ", likedBy=" + likedBy + "]";
	}
	
	
}
