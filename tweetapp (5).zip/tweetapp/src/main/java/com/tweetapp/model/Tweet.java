package com.tweetapp.model;

import javax.persistence.*;
import javax.persistence.Id;

@Entity
public class Tweet {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int tid;
	private String email;
	private String tweet;
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getTweet() {
		return tweet;
	}
	public void setTweet(String tweet) {
		this.tweet = tweet;
	}
	public Tweet(String email, String tweet) {
		super();
		this.email = email;
		this.tweet = tweet;
	}
	public Tweet() {
		super();
	}
	@Override
	public String toString() {
		return "Tweet [email=" + email + ", tweet=" + tweet + "]";
	}
	

}
