package com.tweetapp.service;

import java.sql.SQLException;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tweetapp.exception.TweetAppExceptionHandler;
import com.tweetapp.model.User;
import com.tweetapp.repository.UsersRepo;

@Service
public class UserServiceImpl implements UserService{
	
	//UserRepo userRepo=new UserRepo();
	
	@Autowired
	UsersRepo userRepo;

	@Override
	public User register(User user) throws SQLException {
		return userRepo.save(user);
	}

	@Override
	public boolean logout(String email) {
		// TODO Auto-generated method stub
		System.out.println("Logout in UserServiceImpl");
		try {
			User user = userRepo.findByEmail(email);
			if (user == null) {
				throw new TweetAppExceptionHandler("Username Not Found!!");
			}
			return true;

		} catch (Exception ex) {
			System.out.println("Exception");
			return false;
		}
	}

	@Override
	public List<User> viewAllUsers() {
		// TODO Auto-generated method stub
		return userRepo.findAll();
	}

	@Override
	public boolean isPasswordMatch(String username, String enteredOldPassword) {
		// TODO Auto-generated method stub
		System.out.println("isPasswordMatch in UserServiceImpl");
		try {
			User user = userRepo.findByEmail(username);
			if (user == null) {
				throw new TweetAppExceptionHandler("Username Not Found!!");
			}
			if (user.getPassword().equals(enteredOldPassword)) {
				return true;
			}
			throw new TweetAppExceptionHandler("Your Old password and entered Password Not Matched");
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			return false;
		}
	}

	@Override
	public boolean resetPassword(String username, String oldPassword, String newPassword) {
		// TODO Auto-generated method stub
		try {
		User user = userRepo.findByEmail(username);
		if (user == null) {
			throw new TweetAppExceptionHandler("Username Not Found!!");
		}
		if (user.getPassword().equals(oldPassword)) {
			changePassword(newPassword,user);
			return true;
		}
		throw new TweetAppExceptionHandler("Your Old password and entered Password Not Matched");
	} catch (Exception ex) {
		System.out.println(ex.getMessage());
		return false;
	}
}

	@Override
	public User findUser(String email) {
		// TODO Auto-generated method stub
		return userRepo.findByEmail(email);
	}

	@Override
	public void forgotPassword(String username, String newPassword) {
		// TODO Auto-generated method stub
		try {
		User user = userRepo.findByEmail(username);
		if (user == null) {
			throw new TweetAppExceptionHandler("Username Not Found!!");
		}
		changePassword(newPassword, user);
	} catch (Exception ex) {
		System.out.println(ex.getMessage());
	}
	}
	
	private void changePassword(String newPassword, User user) {
	System.out.println("changePassword in UserServiceImpl");
	user.setPassword(newPassword);
	userRepo.updatePassword(user.getEmail(),newPassword);
}
	
	
	
//	@Override
//	public String register(User userModel) {
//		System.out.println("Register in UserServiceImpl");
//		try {
//			User user = userRepo.findByEmail(userModel.getEmail());
//			System.out.println(user);
//			if (user == null) {
//				System.out.println("In register method");
//				userRepo.addUser(userModel);
//				return "Registration successful, Login in...";
//			}
//			throw new TweetAppExceptionHandler("User already registered, Login Now");
//		} catch (Exception ex) {
//			return ex.getMessage();
//		}
//
//	}
//
//	@Override
//	public List<String> viewAllUsers() {
//		System.out.println("In user service to get all the users");
//		return userRepo.findAll().stream().map(o -> o.getEmail()).collect(Collectors.toList());
//	}
//	
//	@Override
//	public boolean login(String email, String password) {
//		System.out.println("Login in UserServiceImpl");
//		// TODO Auto-generated method stub
//		User user=userRepo.findByEmail(email);
//		if(user.getEmail().equalsIgnoreCase(email)&&user.getPassword().equalsIgnoreCase(password)) {
//			System.out.println("User Loginned SUccessfully");
//			return true;
//		}
//		return false;
//	}
//
//	@Override
//	public void forgotPassword(String username, String newPassword) {
//		try {
//			User user = userRepo.findByEmail(username);
//			if (user == null) {
//				throw new TweetAppExceptionHandler("Username Not Found!!");
//			}
//			changePassword(newPassword, user);
//		} catch (Exception ex) {
//			System.out.println(ex.getMessage());
//		}
//
//	}
//
//	@Override
//	public boolean isPasswordMatch(String username, String enteredOldPassword) {
//		System.out.println("isPasswordMatch in UserServiceImpl");
//		try {
//			User user = userRepo.findByEmail(username);
//			if (user == null) {
//				throw new TweetAppExceptionHandler("Username Not Found!!");
//			}
//			if (user.getPassword().equals(enteredOldPassword)) {
//				return true;
//			}
//			throw new TweetAppExceptionHandler("Your Old password and entered Password Not Matched");
//		} catch (Exception ex) {
//			System.out.println(ex.getMessage());
//			return false;
//		}
//	}
//
//	private void changePassword(String newPassword, User user) {
//		System.out.println("changePassword in UserServiceImpl");
//		user.setPassword(newPassword);
//		userRepo.updatePassword(user.getEmail(),newPassword);
//	}
//	
//	@Override
//	public boolean resetPassword(String username, String oldPassword, String newPassword) {
//		System.out.println("resetPassword in UserServiceImpl");
//		try {
//			User user = userRepo.findByEmail(username);
//			if (user == null) {
//				throw new TweetAppExceptionHandler("Username Not Found!!");
//			}
//			if (user.getPassword().equals(oldPassword)) {
//				changePassword(newPassword,user);
//				return true;
//			}
//			throw new TweetAppExceptionHandler("Your Old password and entered Password Not Matched");
//		} catch (Exception ex) {
//			System.out.println(ex.getMessage());
//			return false;
//		}
//	}
//	@Override
//	public boolean logout(String username) {
//		System.out.println("Logout in UserServiceImpl");
//		try {
//			User user = userRepo.findByEmail(username);
//			if (user == null) {
//				throw new TweetAppExceptionHandler("Username Not Found!!");
//			}
//			return true;
//
//		} catch (Exception ex) {
//			System.out.println("Exception");
//			return false;
//		}
//	}
//	
//	@Override
//	public User findUser(String email) {
//		User user=null;
//		try {
//			 user = userRepo.findByEmail(email);
//			if (user == null) {
//				throw new TweetAppExceptionHandler("Username Not Found!!");
//			}
//			else {
//				return user;
//			}
//		} catch (Exception ex) {
//			System.out.println(ex.getMessage());
//		}
//		return user;
//	}

}
