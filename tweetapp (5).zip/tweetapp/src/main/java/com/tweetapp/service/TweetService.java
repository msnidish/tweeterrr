package com.tweetapp.service;

import java.util.List;
import java.util.Map;

import com.tweetapp.model.Like;
import com.tweetapp.model.Tweet;
import com.tweetapp.model.TweetReply;

public interface TweetService {
	
	Tweet postATweet(Tweet tweet);
    List<Tweet> viewTweetByUser(String username);
    Map<String, List<String>> viewTweetByAllUser();
	void updateTweet(String email, String tweet, int id);
	List<Tweet> deleteTweet(String email,int id);
	Like likeTweet(Like like);
	List<Like> getAllLikes();
	TweetReply postReply(TweetReply tweetReply);
	Map<String, List<String>> getAllReply();
}
