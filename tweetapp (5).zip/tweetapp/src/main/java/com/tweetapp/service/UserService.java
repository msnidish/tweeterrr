package com.tweetapp.service;

import java.sql.SQLException;
import java.util.List;

import com.tweetapp.model.User;

public interface UserService {
	
	public User register(User user) throws SQLException;
	//public List<User> login(String email,String password);
	public boolean logout(String email);
	public List<User> viewAllUsers();
	public boolean isPasswordMatch(String username, String enteredOldPassword);
	public boolean resetPassword(String username, String oldPassword, String newPassword);
	public User findUser(String email);
	void forgotPassword(String username, String newPassword);

}
